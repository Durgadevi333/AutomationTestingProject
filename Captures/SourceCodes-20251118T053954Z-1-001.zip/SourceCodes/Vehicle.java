package week2session3;
/*
 * WAP to demonstrate on the concept of polymorphism, method overriding, 
 * and dynamic method dispatch in Java
 */
class Vehicle
{
    void start() 
    {
        System.out.println("Vehicle started.");
    }
}

class Car extends Vehicle 
{
    @Override
    void start() 
    {
        System.out.println("Car started.");
    }
}

class Motorcycle extends Vehicle
{
    @Override
    void start() 
    {
        System.out.println("Motorcycle started.");
    }
}

class Garage 
{
    void serviceVehicle(Vehicle vehicle)
    {
        vehicle.start();
        System.out.println("Vehicle serviced.");
    }
}

class VehicleMain 
{
    public static void main(String[] args) {
        Car car = new Car();
        Motorcycle motorcycle = new Motorcycle();

        Garage garage = new Garage();
        garage.serviceVehicle(car);
        garage.serviceVehicle(motorcycle);
    }
}
