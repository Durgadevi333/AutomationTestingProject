package week2session3;
/*
 * WAP to demonstrate on the concept of constructor overloading and its 
 * usage in Java.
 */
class Student 
{
    private String name;
    private int age;
    private String department;

    Student() 
    {
        this.name = "Raj";
        this.age = 20;
        this.department = "Unassigned";
    }

    Student(String name, int age)
    {
        this.name = name;
        this.age = age;
        this.department = "IT";
    }

    Student(String name, int age, String department) 
    {
        this.name = name;
        this.age = age;
        this.department = department;
    }

    String getName()
    {
        return name;
    }

    int getAge() 
    {
        return age;
    }

    String getDepartment() 
    {
        return department;
    }
}
class StudentMain {
    public static void main(String[] args)
    {
        Student student1 = new Student();
        Student student2 = new Student("Mona", 20);
        Student student3 = new Student("Mamta", 21, "Computer Science");

        System.out.println("Student: Name=" + student1.getName() + ", Age=" + student1.getAge() + ", Department=" + student1.getDepartment());
        System.out.println("Student: Name=" + student2.getName() + ", Age=" + student2.getAge() + ", Department=" + student2.getDepartment());
        System.out.println("Student: Name=" + student3.getName() + ", Age=" + student3.getAge() + ", Department=" + student3.getDepartment());
    }
}

